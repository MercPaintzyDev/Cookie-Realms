# Cookie Realms

A powerful Chrome extension for managing Roblox account cookies with multi-account support.

---

## Description

Cookie Realms is a Chrome extension designed for Roblox users who need to manage multiple accounts efficiently. It allows you to store, switch between, and refresh Roblox account cookies with ease. The extension features an account manager with validity status indicators and auto-friend request capabilities.

---

## Features

- Session Management - Apply .ROBLOSECURITY cookies to log into Roblox accounts
- Kick All Sessions - Log out all active sessions and refresh the cookie
- Account Manager - Store multiple accounts with avatars, Robux balance, and validity status
- Auto Friend Requests - Automatically send friend requests to a list of usernames
- Telegram Support - Quick access to the official Telegram channel

---

## Installation

1. Download the extension files from the repository.
2. Open Chrome and go to chrome://extensions/.
3. Enable Developer mode (toggle in the top right).
4. Click "Load unpacked".
5. Select the folder containing the extension files.
6. The extension icon will appear in your Chrome toolbar.

---

## How to Use

---

### Tab 1: Session Management

#### Apply Cookie
1. Copy your .ROBLOSECURITY cookie from Roblox (see FAQ below).
2. Paste it into the input field.
3. Click "Apply Cookie".
4. The extension will log you into the account.
5. The account will be automatically saved to the Account Manager.

#### Kick All Sessions
1. Click the "Kick All & Refresh" button.
2. This will log out all active devices connected to your account.
3. A fresh cookie will be generated.
4. The new cookie is automatically copied to your clipboard.
5. The account in Account Manager will be updated with the new cookie.

#### Quick Actions
- Grab Cookie: Copies your current session cookie to the clipboard.
- Logout: Logs out and clears the cookie from the extension.

---

### Tab 2: Account Manager

#### Account List
- All saved accounts appear with their avatars and Robux balance.
- The account you're currently logged into will have a blue highlight.

#### Status Indicator
- Green: Cookie is valid and working
- Red: Cookie is invalid or expired

#### Switch Account
- Simply click on any account in the list.
- The extension will instantly switch to that account.
- Roblox tabs will automatically reload.

#### Copy Cookie
- Click the copy button next to any account.
- The account's cookie will be copied to your clipboard.

#### Refresh Robux
- Click the refresh button next to any account.
- The Robux balance will be updated instantly.

#### Remove Account
- Click the delete button next to any account.
- The account will be removed from the list.

---

### Tab 3: Auto Friend Requests

#### Add Username
1. Type a Roblox username into the input field.
2. Click "Add".
3. The username will appear in the list.

#### Auto Send
- When you Apply a Cookie or Kick All Sessions, the extension automatically sends friend requests to all saved usernames.
- No manual action is needed — it happens in the background.

#### Remove Username
- Click the red X button next to any username.
- The user will be removed from the auto-friend list.

---

### Telegram Button

- Located at the bottom of the extension popup.
- Click it to join the official Telegram channel.
- Get updates, support, and new features.

---

## FAQ

---

### Where do I get my .ROBLOSECURITY cookie?

1. Open Roblox in your browser.
2. Press F12 to open DevTools.
3. Go to the Application tab.
4. Expand Cookies -> https://www.roblox.com.
5. Find the row with name .ROBLOSECURITY.
6. Copy the Value column.
7. Paste it into the extension.

---

### Why does my account show "Invalid" in Account Manager?

The cookie has expired or is no longer valid. To fix this:
- Click "Kick All & Refresh" in the Session tab.
- Or click the refresh button next to the account in Account Manager.

---

### How do I switch accounts?

Simply click on any account in the Account Manager tab. The extension will switch to that account instantly and reload Roblox tabs.

---

### Are my cookies stored securely?

Yes. Cookies are stored locally in Chrome's storage and are only used for the extension's functionality. They are not sent anywhere except to Roblox for authentication.

---

### How do I update the Robux balance?

Click the refresh button next to any account in the Account Manager. The balance will update immediately.

---

### Can I use this on multiple devices?

Yes, but you'll need to install the extension on each device and add your accounts separately. The data is stored locally on each device.

---

### Why aren't my friend requests being sent?

Make sure:
1. You are logged into a valid Roblox account.
2. The usernames you added exist on Roblox.
3. You have applied a cookie or kicked sessions to trigger the auto-friend process.

---

### How do I remove an account?

Click the delete button next to the account in the Account Manager. The account will be removed from the list.

---

### What do the status dots mean?

- Green pulsing: Cookie is valid and working
- Red pulsing: Cookie is invalid or expired
- Yellow pulsing: Checking validity

---

## Disclaimer

This extension is for educational purposes only. Use at your own risk. The developers are not responsible for any account bans or issues caused by using this extension. Always respect Roblox's Terms of Service.

---

## Contact

Join our Telegram channel for updates and support:  
https://t.me/cookierealms

---

## License

MIT License — Free to use and modify.

---

Cookie Realms v1.3

---

# Cookie Realms (Русский)

Мощное расширение для Chrome для управления куки-файлами аккаунтов Roblox с поддержкой нескольких аккаунтов.

---

## Описание

Cookie Realms — это расширение для Chrome, разработанное для пользователей Roblox, которым необходимо эффективно управлять несколькими аккаунтами. Оно позволяет легко сохранять, переключаться между и обновлять куки-файлы аккаунтов Roblox. Расширение включает менеджер аккаунтов с индикаторами статуса валидности и функцию автоматической отправки запросов в друзья.

---

## Возможности

- Управление сессией - Применяйте куки .ROBLOSECURITY для входа в аккаунты Roblox
- Кикнуть все сессии - Выход из всех активных сессий и обновление куки
- Менеджер аккаунтов - Хранение нескольких аккаунтов с аватарами, балансом Robux и статусом валидности
- Авто-запросы в друзья - Автоматическая отправка запросов в друзья по списку имён
- Поддержка Telegram - Быстрый доступ к официальному Telegram-каналу

---

## Установка

1. Скачайте файлы расширения из репозитория.
2. Откройте Chrome и перейдите на chrome://extensions/.
3. Включите Режим разработчика (переключатель в правом верхнем углу).
4. Нажмите "Загрузить распакованное расширение".
5. Выберите папку с файлами расширения.
6. Иконка расширения появится на панели инструментов Chrome.

---

## Как использовать

---

### Вкладка 1: Управление сессией

#### Применить куки
1. Скопируйте куку .ROBLOSECURITY из Roblox (см. FAQ ниже).
2. Вставьте её в поле ввода.
3. Нажмите "Применить куки".
4. Расширение войдёт в аккаунт.
5. Аккаунт будет автоматически сохранён в Менеджере аккаунтов.

#### Кикнуть все сессии
1. Нажмите кнопку "Кикнуть и обновить".
2. Это выйдет из всех активных устройств, подключённых к вашему аккаунту.
3. Будет сгенерирована новая кука.
4. Новая кука автоматически копируется в буфер обмена.
5. Аккаунт в Менеджере аккаунтов будет обновлён новой кукой.

#### Быстрые действия
- Скопировать куки: Копирует текущую сессионную куку в буфер обмена.
- Выйти: Выходит и удаляет куку из расширения.

---

### Вкладка 2: Менеджер аккаунтов

#### Список аккаунтов
- Все сохранённые аккаунты отображаются с аватарами и балансом Robux.
- Аккаунт, в который вы сейчас вошли, будет подсвечен синим цветом.

#### Индикатор статуса
- Зелёный: Кука валидна и работает
- Красный: Кука невалидна или истекла

#### Переключить аккаунт
- Просто нажмите на любой аккаунт в списке.
- Расширение мгновенно переключится на этот аккаунт.
- Вкладки Roblox автоматически перезагрузятся.

#### Копировать куку
- Нажмите кнопку копировать рядом с любым аккаунтом.
- Кука аккаунта будет скопирована в буфер обмена.

#### Обновить Robux
- Нажмите кнопку обновить рядом с любым аккаунтом.
- Баланс Robux будет обновлён мгновенно.

#### Удалить аккаунт
- Нажмите кнопку удалить рядом с любым аккаунтом.
- Аккаунт будет удалён из списка.

---

### Вкладка 3: Авто-запросы в друзья

#### Добавить никнейм
1. Введите никнейм Roblox в поле ввода.
2. Нажмите "Добавить".
3. Никнейм появится в списке.

#### Авто-отправка
- Когда вы Применяете куку или Кикаете сессии, расширение автоматически отправляет запросы в друзья всем сохранённым пользователям.
- Действие происходит в фоновом режиме — ничего не нужно делать вручную.

#### Удалить никнейм
- Нажмите красный X рядом с любым никнеймом.
- Пользователь будет удалён из списка авто-запросов.

---

### Кнопка Telegram

- Находится в нижней части попапа расширения.
- Нажмите её, чтобы присоединиться к официальному Telegram-каналу.
- Получайте обновления, поддержку и новые функции.

---

## Часто задаваемые вопросы

---

### Где взять куку .ROBLOSECURITY?

1. Откройте Roblox в браузере.
2. Нажмите F12, чтобы открыть DevTools.
3. Перейдите на вкладку Application.
4. Разверните Cookies -> https://www.roblox.com.
5. Найдите строку с именем .ROBLOSECURITY.
6. Скопируйте значение из колонки Value.
7. Вставьте его в расширение.

---

### Почему мой аккаунт показывает "Невалидный" в Менеджере аккаунтов?

Кука истекла или больше недействительна. Чтобы исправить это:
- Нажмите "Кикнуть и обновить" на вкладке Сессия.
- Или нажмите кнопку обновить рядом с аккаунтом в Менеджере аккаунтов.

---

### Как переключиться между аккаунтами?

Просто нажмите на любой аккаунт на вкладке Менеджер аккаунтов. Расширение мгновенно переключится на этот аккаунт и перезагрузит вкладки Roblox.

---

### Мои куки хранятся в безопасности?

Да. Куки хранятся локально в хранилище Chrome и используются только для функциональности расширения. Они никуда не отправляются, кроме как в Roblox для аутентификации.

---

### Как обновить баланс Robux?

Нажмите кнопку обновить рядом с любым аккаунтом в Менеджере аккаунтов. Баланс обновится мгновенно.

---

### Можно ли использовать это на нескольких устройствах?

Да, но вам нужно установить расширение на каждом устройстве и добавить аккаунты отдельно. Данные хранятся локально на каждом устройстве.

---

### Почему не отправляются запросы в друзья?

Убедитесь, что:
1. Вы вошли в валидный аккаунт Roblox.
2. Добавленные никнеймы существуют в Roblox.
3. Вы применили куку или кикнули сессии, чтобы запустить процесс авто-запросов.

---

### Как удалить аккаунт?

Нажмите кнопку удалить рядом с аккаунтом в Менеджере аккаунтов. Аккаунт будет удалён из списка.

---

### Что означают статусные точки?

- Зелёная пульсирующая: Кука валидна и работает
- Красная пульсирующая: Кука невалидна или истекла
- Жёлтая пульсирующая: Проверка валидности

---

## Отказ от ответственности

Это расширение предназначено только для образовательных целей. Используйте на свой страх и риск. Разработчики не несут ответственности за блокировки аккаунтов или другие проблемы, вызванные использованием этого расширения. Всегда соблюдайте Условия использования Roblox.

---

## Контакты

Присоединяйтесь к нашему Telegram-каналу для обновлений и поддержки:  
https://t.me/cookierealms

---

## Лицензия

Лицензия MIT — свободно для использования и модификации.

---

Cookie Realms v1.3